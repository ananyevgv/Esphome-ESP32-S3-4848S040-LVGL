Картинки тут https://github.com/alaltitov/display/tree/main/src/weather
